import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="toor123",
  database='parking'
)
mycursor = mydb.cursor()

