import cv2
import requests
from pyzbar.pyzbar import decode

# URL of the backend server
# BACKEND_URL = "http://your-backend-api-endpoint"

def scan_barcode(frame):
    barcodes = decode(frame)
    for barcode in barcodes:
        barcode_data = barcode.data.decode('utf-8')
        return barcode_data
    return None

def camSCan():
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()

        barcode_data = scan_barcode(frame)
        if barcode_data:
            return barcode_data

            # Send barcode data to the backend server
            # payload = {"barcode": barcode_data}
            # response = requests.post(BACKEND_URL, json=payload)

            # Handle the response if necessary
            # print("Backend Response:", response.status_code, response.text)

        cv2.imshow("Barcode Scanner", frame)

        if cv2.waitKey(1):
            break

    cap.release()
    cv2.destroyAllWindows()

# if __name__ == "__main__":
#     main()
