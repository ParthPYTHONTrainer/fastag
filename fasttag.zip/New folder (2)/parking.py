from connection import *
import cv2
from pyzbar.pyzbar import decode
from usingcamera import camSCan

barcode_data=camSCan()

def sendCode(barcode_data):
    barcodenum=barcode_data
    try:
        sql=(f"select * from customers WHERE codenum = {barcodenum};")
        mycursor.execute(sql)
        balance = mycursor.fetchall()
        if(balance[0][3]) > 24:
            NewBalance=balance[0][3]-25
            sql=(f"UPDATE customers SET balance = '{NewBalance}' WHERE codenum = {barcodenum}")
            mycursor.execute(sql)
            mydb.commit()
        else:
            print("insufficient balance")

    except:
        print("Record not found")
sendCode(barcode_data)
# Path to the barcode image file on your computer
# BARCODE_IMAGE_PATH = "japan7896.png"

# def load_barcode_image(image_path):
#     return cv2.imread(image_path)

# def scan_barcode(image):
#     barcodes = decode(image)
#     for barcode in barcodes:
#         barcode_data = barcode.data.decode('utf-8')
#         return barcode_data
#     return None

# def main():
#     # Load barcode image from local file system
#     barcode_image = load_barcode_image(BARCODE_IMAGE_PATH)

#     if barcode_image is not None:
#         barcode_data = scan_barcode(barcode_image)
#         if barcode_data:
#             print("Barcode Detected:", barcode_data)
#             sendCode(barcode_data)
#         else:
#             print("No barcode detected in the provided image.")
#     else:
#         print("Failed to load the barcode image. Please check the file path.")

# if __name__ == "__main__":
#     main()

