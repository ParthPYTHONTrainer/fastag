from connection import *
def recharge():
    money=int(input('enter money in rs:'))
    try:
        sql1=(f"select * from customers WHERE codenum = {barcodeVerify};")
        mycursor.execute(sql1)
        balance = mycursor.fetchall()
        money+=balance[0][3]
        sql=(f"UPDATE customers SET balance = '{money}' WHERE codenum = {barcodeVerify}")
        mycursor.execute(sql)
        mydb.commit()
    except:
        print("Record not found")

def balanceCheck():
    try:
        sql=(f"select * from customers WHERE codenum = {barcodeVerify};")
        mycursor.execute(sql)
        balance = mycursor.fetchall()
        print(f"your balance is {balance[0][3]} ")
    except:
        print("Record not found")
    
try:
    barcodeVerify=input("please verify your barcode: ")
    sql=f"select * from customers WHERE codenum = {barcodeVerify};"
    
    mycursor.execute(sql)
    verification = mycursor.fetchall()
    mydb.commit()
    if verification:
        print("thanx for verification")
        print("enter 1 for recharg , enter 2 for check balance , 3 for exit: ")
        clientinput=int(input("enter 1,2,3"))
        if (clientinput==1):
            recharge()
        elif(clientinput==2):
            balanceCheck()
        elif(clientinput==3):
            exit()
        else:
            ("enter valid input")
        
    else:
        print("not found")
except:
    print("barcode not found")
