import mysql.connector
import random
import barcode
from barcode.writer import ImageWriter

# Generate a random 9-digit number

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="toor123",
  database='parking'
)
mycursor = mydb.cursor()

mycursor.execute("drop table customers;")