from connection import *
import random
import barcode
from barcode.writer import ImageWriter

# Generate a random 9-digit number


##############################################################
def randnum():
    barcode_number = random.randint(100000000, 999999999)
    return (barcode_number)
def bar_code_generator(barcode_number,barCodeName):
    barcode.generate('code128', barcode_number, writer=ImageWriter(), output=barCodeName)

def registration():
    name=input("enter name: ")
    vehical=input("enter veh num: ")
    imgname=name+vehical+'.png'
    barcode=str(randnum())
    bar_code_generator(barcode,(name+vehical))
    val = (name,vehical,0 ,barcode,imgname)
    try:
        sql="insert into customers(name,vehical_number,balance,codenum,codeimg) values(%s,%s,%s,%s,%s);"
        mycursor.execute("CREATE TABLE customers (id int NOT NULL AUTO_INCREMENT,name VARCHAR(255), vehical_number VARCHAR(255),balance int,codenum TEXT, codeimg TEXT,PRIMARY KEY (id));")
        mycursor.execute(sql,val)
        mydb.commit()
        print("registration succesfull")
    except:
        sql="insert into customers(name,vehical_number,balance,codenum,codeimg) values(%s,%s,%s,%s,%s);"
        mycursor.execute(sql,val)
        mydb.commit()
        print("registration succesfull")
def showRegistration():
    try:
        sql="select * from customers"
        mycursor.execute(sql)
        allregistraion = mycursor.fetchall()
        for reg in allregistraion:
            print(reg)
    except:
        print("NO data found")
def delrecord():
    ID=input("enter Id to delete record : ")
    try:
        sql=(f"DELETE FROM customers WHERE id = {ID}")
        mycursor.execute(sql)
        print("delete successfull")
    except:
        print("Record not found")

def update():
    ID=input("enter Id to update record : ")
    column_name=input("enter column name to update")
    new_value=input("enter cnew value to update")
    try:
        sql=(f"UPDATE customers SET {column_name} = '{new_value}' WHERE id = {ID}")
        mycursor.execute(sql)
        print("delete successfull")
    except:
        print("Record not found")

    


while True:
    print("enter 1 for registration \nenter 2 for update record \nenter 3 for delete record \nenter 4 for show data \nenter 5 for exit ")
    try:
        userinput=int(input("enter 1 ,2 ,3, 4 ,5: "))
    except:
        print("enter a valid input: ")
    if(userinput==1):
        registration()
    elif(userinput==2):
        update()
    elif(userinput==3):
        delrecord()
    elif(userinput==4):
        showRegistration()
    elif(userinput==5):
        exit()    
    else:
        print('enter 1,2,3 ,4,5 only')